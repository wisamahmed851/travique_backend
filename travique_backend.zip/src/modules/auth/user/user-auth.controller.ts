import {
  Body,
  Controller,
  Get,
  HttpCode,
  Post,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { UserLoginDto } from './dtos/user-login.dto';
import { UserAuthService } from './user-auth.service';
import { UserJwtAuthGuard } from './user-jwt.guard';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { User } from 'src/modules/users/entity/user.entity';
import { UpdateProfileDto, UserRegisterDto } from './dtos/user-auth.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { multerConfig } from 'src/common/utils/multer.config';
import { RolesGuard } from 'src/common/guards/roles.guard';
import { Roles } from 'src/common/decorators/roles.decorator';

@Controller('user')
export class UserAuthController {
  constructor(private readonly userAuthService: UserAuthService) { }

  @Post('register')
  async register(@Body() body: UserRegisterDto) {
    const { userWithRole, access_token } = await this.userAuthService.register(body);
    const user = {
      name: userWithRole.name,
      image: userWithRole.image,
    }
    return {
      success: true,
      message: 'User registered successfully',
      data: { user, access_token },
    };
  }

  @Post('login')
  @HttpCode(200)
  async login(@Body() body: UserLoginDto) {
    const user = await this.userAuthService.validateUser(body.email, body.password);
    const { token, refresh_token, role } = await this.userAuthService.login(user);
    return {
      success: true,
      message: 'User logged in successfully',
      data: { access_token: token, refresh_token, role },
    };
  }

  @Post('refresh-token')
  async refreshToken(@Body('refresh_token') refreshToken: string) {
    const result = await this.userAuthService.refreshToken(refreshToken);
    return {
      success: true,
      message: 'Token refreshed successfully',
      data: result,
    };
  }

  @Get('profile')
  @UseGuards(UserJwtAuthGuard)
  async profile(@CurrentUser() user: User) {
    const profile = await this.userAuthService.profile(user);
    return { success: true, message: 'Profile fetched successfully', data: profile };
  }

  @Post('update-profile')
  @UseGuards(UserJwtAuthGuard)
  @UseInterceptors(FileInterceptor('image', multerConfig('uploads')))
  async profileUpdate(
    @CurrentUser() user: User,
    @Body() body: UpdateProfileDto,
    @UploadedFile() file: Express.Multer.File,
  ) {
    const updated = await this.userAuthService.profileUpdate(user, file ? { ...body, image: file.filename } : body);
    return { success: true, message: 'Profile updated successfully', data: updated };
  }

  @Post('change-password')
  @UseGuards(UserJwtAuthGuard)
  async changePassword(@Body() body: { oldPassword: string; newPassword: string }, @CurrentUser() user: User) {
    await this.userAuthService.changePassword(body, user);
    return { success: true, message: 'Password updated successfully' };
  }

  @Post('current-location')
  @UseGuards(UserJwtAuthGuard)
  async currentLocation(@CurrentUser() user: User, @Body() body: { langitude: number; latitude: number }) {
    const updated = await this.userAuthService.currentLocation(user.id, body);
    return { success: true, message: 'Location updated successfully', data: updated };
  }

  @Get('mode')
  @UseGuards(UserJwtAuthGuard, RolesGuard)
  @Roles('driver')
  async changeMode(@CurrentUser() user: User) {
    const updated = await this.userAuthService.modeChange(user);
    return {
      success: true,
      message: `Driver is now ${updated.isOnline ? 'Online' : 'Offline'}`,
      data: updated,
    };
  }

  @Post('logout')
  @UseGuards(UserJwtAuthGuard)
  async logout(@CurrentUser() user: User) {
    await this.userAuthService.logout(user);
    return { success: true, message: 'User logged out successfully' };
  }
}
